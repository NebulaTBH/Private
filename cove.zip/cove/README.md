# Cove

Cove is a real-time, Discord-style community chat platform: servers ("coves"), channels,
live messaging, user profiles, and a full server-side-secured admin/moderation panel.

It's a real working application — accounts and passwords are handled for real, messages
and profiles are stored in a real database file that survives restarts, and every admin
action is checked on the server, not just hidden in the UI.

## Tech stack

- **Backend:** Node.js + Express
- **Database:** SQLite via `better-sqlite3` — a real file-based database (`database/cove.db`).
  No separate database server to install; the file persists on disk across restarts.
- **Auth:** bcrypt-hashed passwords, JWT stored in an `httpOnly` cookie (so it can't be read
  or forged by frontend JavaScript), verified on the server on every request.
- **Realtime:** Socket.IO for instant message delivery, typing indicators.
- **Uploads:** Multer, restricted to PNG/JPEG/WEBP/GIF, 5MB max.
- **Frontend:** Plain HTML/CSS/JS (no build step) so it's easy to read, run, and extend.

## Project structure

```
/cove
  server.js              Express app + Socket.IO wiring
  .env.example            Copy to .env and edit
  /database
    schema.sql            Table definitions
    db.js                 DB connection + first-run seed data
    make-admin.js          CLI: promote a user to administrator
  /middleware
    auth.js                Verifies the session cookie, blocks banned users
    admin.js                Requires the admin role (server-side, always)
  /lib
    validate.js             Shared input validation
    upload.js                Multer config with strict image validation
  /routes
    auth.js                 Register / login / logout / session check
    users.js                  Profile viewing + self-service settings
    admin.js                   Admin panel API (all routes require admin role)
    coves.js                    Communities + channels
    messages.js                  Chat history, send, edit, delete
  /public
    index.html               The whole app shell (all views)
    /css/style.css            Styling
    /js/app.js                  Client-side logic
    /uploads/avatars, /banners    Uploaded images land here
```

## Setup

### 1. Install dependencies

```bash
cd cove
npm install
```

### 2. Configure environment variables

```bash
cp .env.example .env
```

Then edit `.env`:

| Variable | Description |
|---|---|
| `PORT` | Port to run the server on (default `3000`) |
| `JWT_SECRET` | Secret used to sign session tokens. **Change this to a long random string before running in production.** Generate one with: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` |
| `DATABASE_PATH` | Where the SQLite file lives (default `./database/cove.db`) |
| `COOKIE_SECURE` | Set to `true` once you're serving over HTTPS, so session cookies require HTTPS |

### 3. Run it

```bash
npm start
```

Visit `http://localhost:3000`. The database file and tables are created automatically on
first run — there's no separate "run migrations" step.

## Creating the first administrator account

**The very first account ever registered on a fresh database is automatically made an
administrator.** So the simplest path is: run the app, register through the UI, and that
account is your admin.

To promote any other existing account to admin later (from the command line, on the server):

```bash
node database/make-admin.js <username>
```

Example: `node database/make-admin.js sam_ocean`

The admin panel (shield icon in the bottom-left user tray) is only shown in the UI to
admins, and every admin API route independently re-checks the account's role on the
server — a non-admin calling those API routes directly still gets rejected.

## What's implemented

- Registration, login, logout with hashed passwords (bcrypt) and persistent sessions
  (JWT in an httpOnly cookie) — refreshing the page keeps you logged in.
- Unique, immutable usernames separate from an editable display name.
- Full profile system: avatar, banner (image or color), about-me, status, account ID and
  creation date, viewable via a profile card popup.
- Settings page with My Account / Appearance / Privacy / Notifications / Security sections;
  profile editing and password changes are fully functional and persist.
- Admin panel: search/view users, rename username or display name, remove avatars/banners,
  ban (with reason, permanent or timed) and unban. A banned user is rejected at login and
  has their active session invalidated — not just flagged in the UI.
- Real-time chat: Socket.IO delivers new messages, edits, and deletions instantly to
  everyone in a channel; typing indicators; full message history persisted in SQLite;
  users can edit/delete their own messages, admins can delete any message.
- Server-side authorization on every sensitive route (auth middleware + a separate admin
  middleware), so the admin panel can't be reached by editing frontend JavaScript.
- File upload validation (type + size) for avatars and banners.
- Toasts, loading/empty/error states, and a dedicated "you're banned" screen.

## Notes / where to take it from here

- Passwords need 8+ characters; usernames are 3–20 lowercase letters/numbers/`_`/`.`.
- SQLite is great for getting a real app running fast; if you outgrow a single file,
  swapping `better-sqlite3` for `pg` (PostgreSQL) mainly touches `database/db.js` and the
  `.prepare(...).run()/.get()/.all()` call sites in `/routes`, since the SQL itself is
  close to standard.
- There's no email verification or password-reset flow yet — a good next feature to add
  alongside a real mail provider.
- Multer 1.x (used here) has known advisories; for a production deployment, upgrade to
  Multer 2.x (`npm install multer@2`) — the API used here is compatible.
