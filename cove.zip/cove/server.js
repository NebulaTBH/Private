require('dotenv').config();
const path = require('path');
const http = require('http');
const express = require('express');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const { Server: SocketServer } = require('socket.io');

const { db } = require('./database/db');
const { JWT_SECRET, requireAuth } = require('./middleware/auth');

const authRoutes = require('./routes/auth');
const usersRoutes = require('./routes/users');
const adminRoutes = require('./routes/admin');
const covesRoutes = require('./routes/coves');
const messagesRoutes = require('./routes/messages');

const app = express();
const server = http.createServer(app);
const io = new SocketServer(server);

const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));

// --- API routes ---
app.use('/api/auth', authRoutes.router);
app.use('/api/users', usersRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/coves', covesRoutes);
app.use('/api/messages', messagesRoutes);

// Current logged-in user's admin flag + banned check is already covered by requireAuth
// re-checked on every request. This lightweight endpoint just confirms the app is up.
app.get('/api/health', (req, res) => res.json({ ok: true }));

// --- Socket.IO realtime chat ---
// Authenticate the socket using the same httpOnly session cookie used for REST calls.
io.use((socket, next) => {
  try {
    const cookieHeader = socket.handshake.headers.cookie || '';
    const match = cookieHeader.match(/(?:^|; )cove_session=([^;]+)/);
    if (!match) return next(new Error('unauthorized'));
    const token = decodeURIComponent(match[1]);
    const payload = jwt.verify(token, JWT_SECRET);

    const user = db.prepare('SELECT id, username, display_name, role FROM users WHERE id = ?').get(payload.userId);
    if (!user) return next(new Error('unauthorized'));

    const activeBan = db.prepare(
      `SELECT 1 FROM bans WHERE user_id = ? AND active = 1
       AND (is_permanent = 1 OR expires_at IS NULL OR expires_at > ?) LIMIT 1`
    ).get(user.id, new Date().toISOString());
    if (activeBan) return next(new Error('banned'));

    socket.user = user;
    next();
  } catch (err) {
    next(new Error('unauthorized'));
  }
});

io.on('connection', (socket) => {
  socket.on('join-channel', (channelId) => {
    // Only allow joining channels that belong to a cove the user is a member of.
    const channel = db.prepare(
      `SELECT ch.id FROM channels ch
       JOIN cove_members m ON m.cove_id = ch.cove_id
       WHERE ch.id = ? AND m.user_id = ?`
    ).get(channelId, socket.user.id);
    if (!channel) return;
    socket.join(`channel:${channelId}`);
  });

  socket.on('leave-channel', (channelId) => {
    socket.leave(`channel:${channelId}`);
  });

  socket.on('typing', (channelId) => {
    socket.to(`channel:${channelId}`).emit('typing', {
      channelId,
      user: { id: socket.user.id, displayName: socket.user.display_name },
    });
  });
});

// Broadcast helpers used by the REST routes after they write to the database,
// so every connected client (including the sender's other tabs) gets the update
// without needing to poll or refresh.
app.set('broadcastMessage', (channelId, message) => {
  io.to(`channel:${channelId}`).emit('message:new', message);
});
app.set('broadcastMessageEdit', (channelId, message) => {
  io.to(`channel:${channelId}`).emit('message:edit', message);
});
app.set('broadcastMessageDelete', (channelId, messageId) => {
  io.to(`channel:${channelId}`).emit('message:delete', { channelId, messageId });
});

// SPA fallback: serve index.html for any non-API GET route so client-side
// view switching (login/app/settings/admin) works on refresh.
app.get(/^(?!\/api|\/uploads).*/, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

server.listen(PORT, () => {
  console.log(`🌊 Cove is running at http://localhost:${PORT}`);
});
