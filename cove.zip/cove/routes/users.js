const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../database/db');
const { requireAuth } = require('../middleware/auth');
const { makeUploader } = require('../lib/upload');
const {
  validateDisplayName,
  validateAboutMe,
  validatePassword,
} = require('../lib/validate');

const router = express.Router();
const avatarUpload = makeUploader('avatars');
const bannerUpload = makeUploader('banners');

function publicProfile(user) {
  return {
    id: user.id,
    username: user.username,
    displayName: user.display_name,
    avatarUrl: user.avatar_url,
    bannerUrl: user.banner_url,
    bannerColor: user.banner_color,
    aboutMe: user.about_me,
    status: user.status,
    role: user.role,
    createdAt: user.created_at,
  };
}

// View any user's public profile card by id
router.get('/:id', requireAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  res.json({ user: publicProfile(user) });
});

// Update own display name / about me / status
router.patch('/me/profile', requireAuth, (req, res) => {
  const { displayName, aboutMe, status } = req.body || {};
  const errors = {};

  if (displayName !== undefined) {
    const err = validateDisplayName(displayName);
    if (err) errors.displayName = err;
  }
  if (aboutMe !== undefined) {
    const err = validateAboutMe(aboutMe);
    if (err) errors.aboutMe = err;
  }
  const allowedStatuses = ['online', 'idle', 'dnd', 'offline'];
  if (status !== undefined && !allowedStatuses.includes(status)) {
    errors.status = 'Invalid status.';
  }

  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ error: 'Validation failed.', fields: errors });
  }

  const updates = [];
  const values = [];
  if (displayName !== undefined) { updates.push('display_name = ?'); values.push(displayName.trim()); }
  if (aboutMe !== undefined) { updates.push('about_me = ?'); values.push(aboutMe.trim()); }
  if (status !== undefined) { updates.push('status = ?'); values.push(status); }
  updates.push('updated_at = ?');
  values.push(new Date().toISOString());
  values.push(req.user.id);

  db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...values);

  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  res.json({ user: publicProfile(updated) });
});

// Change password
router.post('/me/password', requireAuth, (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  const full = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  if (!currentPassword || !bcrypt.compareSync(currentPassword, full.password_hash)) {
    return res.status(400).json({ error: 'Validation failed.', fields: { currentPassword: 'Current password is incorrect.' } });
  }
  const err = validatePassword(newPassword);
  if (err) {
    return res.status(400).json({ error: 'Validation failed.', fields: { newPassword: err } });
  }

  const newHash = bcrypt.hashSync(newPassword, 12);
  db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?')
    .run(newHash, new Date().toISOString(), req.user.id);

  res.json({ ok: true });
});

// Upload avatar
router.post('/me/avatar', requireAuth, (req, res) => {
  avatarUpload.single('avatar')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No file uploaded.' });

    const url = `/uploads/avatars/${req.file.filename}`;
    db.prepare('UPDATE users SET avatar_url = ?, updated_at = ? WHERE id = ?')
      .run(url, new Date().toISOString(), req.user.id);
    res.json({ avatarUrl: url });
  });
});

// Upload banner
router.post('/me/banner', requireAuth, (req, res) => {
  bannerUpload.single('banner')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No file uploaded.' });

    const url = `/uploads/banners/${req.file.filename}`;
    db.prepare('UPDATE users SET banner_url = ?, updated_at = ? WHERE id = ?')
      .run(url, new Date().toISOString(), req.user.id);
    res.json({ bannerUrl: url });
  });
});

// Remove avatar / banner
router.delete('/me/avatar', requireAuth, (req, res) => {
  db.prepare('UPDATE users SET avatar_url = NULL, updated_at = ? WHERE id = ?').run(new Date().toISOString(), req.user.id);
  res.json({ ok: true });
});
router.delete('/me/banner', requireAuth, (req, res) => {
  db.prepare('UPDATE users SET banner_url = NULL, updated_at = ? WHERE id = ?').run(new Date().toISOString(), req.user.id);
  res.json({ ok: true });
});

// Set banner accent color (used when no banner image is set)
router.patch('/me/banner-color', requireAuth, (req, res) => {
  const { color } = req.body || {};
  if (typeof color !== 'string' || !/^#[0-9a-fA-F]{6}$/.test(color)) {
    return res.status(400).json({ error: 'Validation failed.', fields: { color: 'Provide a valid hex color.' } });
  }
  db.prepare('UPDATE users SET banner_color = ?, updated_at = ? WHERE id = ?').run(color, new Date().toISOString(), req.user.id);
  res.json({ ok: true });
});

module.exports = router;
