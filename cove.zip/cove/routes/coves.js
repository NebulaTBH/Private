const express = require('express');
const { db, uuid } = require('../database/db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// List the coves the current user belongs to, each with its channels
router.get('/', requireAuth, (req, res) => {
  const coves = db.prepare(
    `SELECT c.* FROM coves c
     JOIN cove_members m ON m.cove_id = c.id
     WHERE m.user_id = ?
     ORDER BY c.created_at ASC`
  ).all(req.user.id);

  const result = coves.map((cove) => {
    const channels = db.prepare(
      'SELECT id, name, topic, position FROM channels WHERE cove_id = ? ORDER BY position ASC'
    ).all(cove.id);
    return {
      id: cove.id,
      name: cove.name,
      iconText: cove.icon_text,
      ownerId: cove.owner_id,
      channels,
    };
  });

  res.json({ coves: result });
});

// Create a new cove (any logged-in user can start one, like Discord servers)
router.post('/', requireAuth, (req, res) => {
  const { name } = req.body || {};
  if (!name || typeof name !== 'string' || name.trim().length < 2 || name.trim().length > 40) {
    return res.status(400).json({ error: 'Validation failed.', fields: { name: 'Cove name must be 2-40 characters.' } });
  }

  const now = new Date().toISOString();
  const coveId = uuid();
  const iconText = name.trim().split(/\s+/).map((w) => w[0]).join('').slice(0, 3).toUpperCase();

  db.prepare('INSERT INTO coves (id, name, icon_text, owner_id, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(coveId, name.trim(), iconText, req.user.id, now);
  db.prepare('INSERT INTO cove_members (cove_id, user_id, joined_at) VALUES (?, ?, ?)')
    .run(coveId, req.user.id, now);

  const channelId = uuid();
  db.prepare('INSERT INTO channels (id, cove_id, name, topic, position, created_at) VALUES (?, ?, ?, ?, 0, ?)')
    .run(channelId, coveId, 'general', '', now);

  res.status(201).json({
    cove: {
      id: coveId,
      name: name.trim(),
      iconText,
      ownerId: req.user.id,
      channels: [{ id: channelId, name: 'general', topic: '', position: 0 }],
    },
  });
});

// Members list for a cove (for the member sidebar)
router.get('/:id/members', requireAuth, (req, res) => {
  const membership = db.prepare('SELECT 1 FROM cove_members WHERE cove_id = ? AND user_id = ?').get(req.params.id, req.user.id);
  if (!membership) return res.status(403).json({ error: 'You are not a member of this cove.' });

  const members = db.prepare(
    `SELECT u.id, u.username, u.display_name, u.avatar_url, u.status, u.role
     FROM cove_members m JOIN users u ON u.id = m.user_id
     WHERE m.cove_id = ? ORDER BY u.display_name COLLATE NOCASE ASC`
  ).all(req.params.id);

  res.json({
    members: members.map((m) => ({
      id: m.id,
      username: m.username,
      displayName: m.display_name,
      avatarUrl: m.avatar_url,
      status: m.status,
      role: m.role,
    })),
  });
});

module.exports = router;
