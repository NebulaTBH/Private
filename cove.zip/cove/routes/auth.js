const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db, uuid, seedDefaults } = require('../database/db');
const { JWT_SECRET, requireAuth } = require('../middleware/auth');
const {
  validateUsername,
  validateDisplayName,
  validateEmail,
  validatePassword,
} = require('../lib/validate');

const router = express.Router();

const COOKIE_SECURE = process.env.COOKIE_SECURE === 'true';
const SESSION_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

function setSessionCookie(res, userId) {
  const token = jwt.sign({ userId }, JWT_SECRET, { expiresIn: '30d' });
  res.cookie('cove_session', token, {
    httpOnly: true,
    secure: COOKIE_SECURE,
    sameSite: 'lax',
    maxAge: SESSION_MAX_AGE_MS,
  });
}

function publicUser(user) {
  return {
    id: user.id,
    username: user.username,
    displayName: user.display_name,
    email: user.email,
    avatarUrl: user.avatar_url,
    bannerUrl: user.banner_url,
    bannerColor: user.banner_color,
    aboutMe: user.about_me,
    status: user.status,
    role: user.role,
    createdAt: user.created_at,
  };
}

router.post('/register', (req, res) => {
  const { username, displayName, email, password } = req.body || {};

  const errors = {};
  const usernameErr = validateUsername(username);
  if (usernameErr) errors.username = usernameErr;
  const displayNameErr = validateDisplayName(displayName || username);
  if (displayNameErr) errors.displayName = displayNameErr;
  const emailErr = validateEmail(email);
  if (emailErr) errors.email = emailErr;
  const passwordErr = validatePassword(password);
  if (passwordErr) errors.password = passwordErr;

  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ error: 'Validation failed.', fields: errors });
  }

  const usernameLower = username.trim().toLowerCase();
  const emailLower = email.trim().toLowerCase();

  const existingUsername = db.prepare('SELECT id FROM users WHERE username_lower = ?').get(usernameLower);
  if (existingUsername) {
    return res.status(409).json({ error: 'Validation failed.', fields: { username: 'That username is already taken.' } });
  }
  const existingEmail = db.prepare('SELECT id FROM users WHERE email_lower = ?').get(emailLower);
  if (existingEmail) {
    return res.status(409).json({ error: 'Validation failed.', fields: { email: 'An account with that email already exists.' } });
  }

  const passwordHash = bcrypt.hashSync(password, 12);
  const now = new Date().toISOString();
  const userId = uuid();
  const isFirstUser = db.prepare('SELECT COUNT(*) AS c FROM users').get().c === 0;

  db.prepare(
    `INSERT INTO users (id, username, username_lower, display_name, email, email_lower, password_hash, role, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    userId,
    username.trim(),
    usernameLower,
    (displayName || username).trim(),
    email.trim(),
    emailLower,
    passwordHash,
    isFirstUser ? 'admin' : 'member', // first-ever account becomes an admin automatically
    now,
    now
  );

  // Seed a default Cove now that a user exists to own it, and drop new users into it.
  seedDefaults();
  const defaultCove = db.prepare('SELECT id FROM coves ORDER BY created_at ASC LIMIT 1').get();
  if (defaultCove) {
    const alreadyMember = db.prepare('SELECT 1 FROM cove_members WHERE cove_id = ? AND user_id = ?').get(defaultCove.id, userId);
    if (!alreadyMember) {
      db.prepare('INSERT INTO cove_members (cove_id, user_id, joined_at) VALUES (?, ?, ?)').run(defaultCove.id, userId, now);
    }
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  setSessionCookie(res, userId);
  res.status(201).json({ user: publicUser(user) });
});

router.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: 'Username/email and password are required.' });
  }

  const identifier = username.trim().toLowerCase();
  const user = db.prepare(
    'SELECT * FROM users WHERE username_lower = ? OR email_lower = ?'
  ).get(identifier, identifier);

  // Deliberately generic error message so login can't be used to enumerate accounts.
  const genericError = { error: 'Incorrect username/email or password.' };

  if (!user) {
    return res.status(401).json(genericError);
  }

  const passwordOk = bcrypt.compareSync(password, user.password_hash);
  if (!passwordOk) {
    return res.status(401).json(genericError);
  }

  const activeBan = db.prepare(
    `SELECT * FROM bans WHERE user_id = ? AND active = 1
     AND (is_permanent = 1 OR expires_at IS NULL OR expires_at > ?)
     ORDER BY banned_at DESC LIMIT 1`
  ).get(user.id, new Date().toISOString());

  if (activeBan) {
    return res.status(403).json({
      error: 'banned',
      message: 'This account has been banned.',
      reason: activeBan.reason,
      permanent: !!activeBan.is_permanent,
      expiresAt: activeBan.expires_at,
    });
  }

  setSessionCookie(res, user.id);
  res.json({ user: publicUser(user) });
});

router.post('/logout', (req, res) => {
  res.clearCookie('cove_session');
  res.json({ ok: true });
});

router.get('/me', requireAuth, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

module.exports = { router, publicUser };
