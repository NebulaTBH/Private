const express = require('express');
const { db, uuid } = require('../database/db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

function channelBelongsToUser(channelId, userId) {
  return db.prepare(
    `SELECT ch.id, ch.cove_id FROM channels ch
     JOIN cove_members m ON m.cove_id = ch.cove_id
     WHERE ch.id = ? AND m.user_id = ?`
  ).get(channelId, userId);
}

function hydrateMessage(row) {
  const author = db.prepare('SELECT id, username, display_name, avatar_url FROM users WHERE id = ?').get(row.user_id);
  return {
    id: row.id,
    channelId: row.channel_id,
    content: row.content,
    createdAt: row.created_at,
    editedAt: row.edited_at,
    author: author
      ? { id: author.id, username: author.username, displayName: author.display_name, avatarUrl: author.avatar_url }
      : { id: row.user_id, username: 'unknown', displayName: 'Unknown user', avatarUrl: null },
  };
}

// Message history for a channel (most recent 50, oldest first)
router.get('/channel/:channelId', requireAuth, (req, res) => {
  const channel = channelBelongsToUser(req.params.channelId, req.user.id);
  if (!channel) return res.status(403).json({ error: 'You do not have access to this channel.' });

  const before = req.query.before; // ISO timestamp, for pagination/scroll-up
  let rows;
  if (before) {
    rows = db.prepare(
      `SELECT * FROM messages WHERE channel_id = ? AND deleted = 0 AND created_at < ?
       ORDER BY created_at DESC LIMIT 50`
    ).all(req.params.channelId, before);
  } else {
    rows = db.prepare(
      `SELECT * FROM messages WHERE channel_id = ? AND deleted = 0
       ORDER BY created_at DESC LIMIT 50`
    ).all(req.params.channelId);
  }
  rows.reverse();
  res.json({ messages: rows.map(hydrateMessage) });
});

// Send a message (also broadcast over socket.io by the caller in server.js)
router.post('/channel/:channelId', requireAuth, (req, res) => {
  const channel = channelBelongsToUser(req.params.channelId, req.user.id);
  if (!channel) return res.status(403).json({ error: 'You do not have access to this channel.' });

  const { content } = req.body || {};
  if (!content || typeof content !== 'string' || !content.trim()) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }
  if (content.length > 4000) {
    return res.status(400).json({ error: 'Message is too long (4000 character limit).' });
  }

  const id = uuid();
  const now = new Date().toISOString();
  db.prepare('INSERT INTO messages (id, channel_id, user_id, content, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(id, req.params.channelId, req.user.id, content.trim(), now);

  const row = db.prepare('SELECT * FROM messages WHERE id = ?').get(id);
  const message = hydrateMessage(row);
  req.app.get('broadcastMessage')(req.params.channelId, message);
  res.status(201).json({ message });
});

// Edit own message
router.patch('/:id', requireAuth, (req, res) => {
  const msg = db.prepare('SELECT * FROM messages WHERE id = ? AND deleted = 0').get(req.params.id);
  if (!msg) return res.status(404).json({ error: 'Message not found.' });
  if (msg.user_id !== req.user.id) return res.status(403).json({ error: 'You can only edit your own messages.' });

  const { content } = req.body || {};
  if (!content || typeof content !== 'string' || !content.trim()) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  const now = new Date().toISOString();
  db.prepare('UPDATE messages SET content = ?, edited_at = ? WHERE id = ?').run(content.trim(), now, msg.id);

  const updated = hydrateMessage(db.prepare('SELECT * FROM messages WHERE id = ?').get(msg.id));
  req.app.get('broadcastMessageEdit')(msg.channel_id, updated);
  res.json({ message: updated });
});

// Delete own message (admins may delete any message)
router.delete('/:id', requireAuth, (req, res) => {
  const msg = db.prepare('SELECT * FROM messages WHERE id = ? AND deleted = 0').get(req.params.id);
  if (!msg) return res.status(404).json({ error: 'Message not found.' });
  if (msg.user_id !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'You can only delete your own messages.' });
  }

  db.prepare('UPDATE messages SET deleted = 1 WHERE id = ?').run(msg.id);
  req.app.get('broadcastMessageDelete')(msg.channel_id, msg.id);
  res.json({ ok: true });
});

module.exports = router;
