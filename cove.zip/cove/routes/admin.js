const express = require('express');
const { db, uuid } = require('../database/db');
const { requireAuth } = require('../middleware/auth');
const { requireAdmin } = require('../middleware/admin');
const { validateUsername, validateDisplayName } = require('../lib/validate');

const router = express.Router();

// Every route below runs requireAuth then requireAdmin, so the role check
// happens on the server for every request regardless of what the client sends.
router.use(requireAuth, requireAdmin);

function withBanStatus(user) {
  const activeBan = db.prepare(
    `SELECT * FROM bans WHERE user_id = ? AND active = 1
     AND (is_permanent = 1 OR expires_at IS NULL OR expires_at > ?)
     ORDER BY banned_at DESC LIMIT 1`
  ).get(user.id, new Date().toISOString());

  return {
    id: user.id,
    username: user.username,
    displayName: user.display_name,
    email: user.email,
    avatarUrl: user.avatar_url,
    bannerUrl: user.banner_url,
    role: user.role,
    createdAt: user.created_at,
    banned: !!activeBan,
    banInfo: activeBan
      ? {
          reason: activeBan.reason,
          permanent: !!activeBan.is_permanent,
          expiresAt: activeBan.expires_at,
          bannedAt: activeBan.banned_at,
        }
      : null,
  };
}

// List / search users
router.get('/users', (req, res) => {
  const q = (req.query.q || '').trim().toLowerCase();
  let rows;
  if (q) {
    rows = db.prepare(
      `SELECT * FROM users WHERE username_lower LIKE ? OR display_name LIKE ? OR email_lower LIKE ?
       ORDER BY created_at DESC LIMIT 100`
    ).all(`%${q}%`, `%${q}%`, `%${q}%`);
  } else {
    rows = db.prepare('SELECT * FROM users ORDER BY created_at DESC LIMIT 100').all();
  }
  res.json({ users: rows.map(withBanStatus) });
});

// View one user's full admin profile, including ban history
router.get('/users/:id', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  const banHistory = db.prepare('SELECT * FROM bans WHERE user_id = ? ORDER BY banned_at DESC').all(user.id);
  res.json({ user: withBanStatus(user), banHistory });
});

// Change a user's username (admin override - still must remain unique)
router.patch('/users/:id/username', (req, res) => {
  const { username } = req.body || {};
  const err = validateUsername(username);
  if (err) return res.status(400).json({ error: 'Validation failed.', fields: { username: err } });

  const lower = username.trim().toLowerCase();
  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found.' });

  const clash = db.prepare('SELECT id FROM users WHERE username_lower = ? AND id != ?').get(lower, target.id);
  if (clash) return res.status(409).json({ error: 'Validation failed.', fields: { username: 'That username is already taken.' } });

  db.prepare('UPDATE users SET username = ?, username_lower = ?, updated_at = ? WHERE id = ?')
    .run(username.trim(), lower, new Date().toISOString(), target.id);
  res.json({ ok: true });
});

// Change a user's display name
router.patch('/users/:id/display-name', (req, res) => {
  const { displayName } = req.body || {};
  const err = validateDisplayName(displayName);
  if (err) return res.status(400).json({ error: 'Validation failed.', fields: { displayName: err } });

  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found.' });

  db.prepare('UPDATE users SET display_name = ?, updated_at = ? WHERE id = ?')
    .run(displayName.trim(), new Date().toISOString(), target.id);
  res.json({ ok: true });
});

// Remove or replace a user's avatar / banner
router.delete('/users/:id/avatar', (req, res) => {
  const target = db.prepare('SELECT id FROM users WHERE id = ?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found.' });
  db.prepare('UPDATE users SET avatar_url = NULL, updated_at = ? WHERE id = ?').run(new Date().toISOString(), target.id);
  res.json({ ok: true });
});
router.delete('/users/:id/banner', (req, res) => {
  const target = db.prepare('SELECT id FROM users WHERE id = ?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found.' });
  db.prepare('UPDATE users SET banner_url = NULL, updated_at = ? WHERE id = ?').run(new Date().toISOString(), target.id);
  res.json({ ok: true });
});

// Ban a user
router.post('/users/:id/ban', (req, res) => {
  const { reason, permanent, durationHours } = req.body || {};
  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found.' });

  if (target.id === req.user.id) {
    return res.status(400).json({ error: 'You cannot ban your own account.' });
  }
  if (target.role === 'admin') {
    return res.status(400).json({ error: 'Administrators cannot be banned from the panel. Remove their admin role first.' });
  }
  if (!reason || typeof reason !== 'string' || reason.trim().length < 3) {
    return res.status(400).json({ error: 'Validation failed.', fields: { reason: 'Please provide a ban reason (at least 3 characters).' } });
  }

  const isPermanent = !!permanent;
  let expiresAt = null;
  if (!isPermanent && durationHours) {
    const hours = Number(durationHours);
    if (!Number.isFinite(hours) || hours <= 0) {
      return res.status(400).json({ error: 'Validation failed.', fields: { durationHours: 'Duration must be a positive number of hours.' } });
    }
    expiresAt = new Date(Date.now() + hours * 60 * 60 * 1000).toISOString();
  }

  // Deactivate any previous active bans, then insert the new one
  db.prepare('UPDATE bans SET active = 0 WHERE user_id = ? AND active = 1').run(target.id);

  const banId = uuid();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO bans (id, user_id, reason, is_permanent, expires_at, banned_by, banned_at, active)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1)`
  ).run(banId, target.id, reason.trim(), isPermanent ? 1 : 0, expiresAt, req.user.id, now);

  res.json({ ok: true, ban: { id: banId, reason: reason.trim(), permanent: isPermanent, expiresAt, bannedAt: now } });
});

// Unban a user
router.post('/users/:id/unban', (req, res) => {
  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found.' });

  const now = new Date().toISOString();
  const result = db.prepare(
    'UPDATE bans SET active = 0, unbanned_by = ?, unbanned_at = ? WHERE user_id = ? AND active = 1'
  ).run(req.user.id, now, target.id);

  if (result.changes === 0) {
    return res.status(400).json({ error: 'This user does not have an active ban.' });
  }
  res.json({ ok: true });
});

// Promote / demote admin role
router.patch('/users/:id/role', (req, res) => {
  const { role } = req.body || {};
  if (!['admin', 'member'].includes(role)) {
    return res.status(400).json({ error: 'Validation failed.', fields: { role: 'Role must be "admin" or "member".' } });
  }
  const target = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found.' });

  if (target.id === req.user.id && role === 'member') {
    return res.status(400).json({ error: 'You cannot remove your own admin role.' });
  }

  db.prepare('UPDATE users SET role = ?, updated_at = ? WHERE id = ?').run(role, new Date().toISOString(), target.id);
  res.json({ ok: true });
});

module.exports = router;
