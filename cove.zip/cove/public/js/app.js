/* ==========================================================================
   Cove — client application
   Vanilla JS, no build step. Talks to the REST API under /api and to
   Socket.IO for realtime messages.
   ========================================================================== */

const state = {
  user: null,
  coves: [],
  activeCoveId: null,
  activeChannelId: null,
  members: [],
  socket: null,
  typingTimeout: null,
  typingUsers: new Map(),
};

// ---------------------------------------------------------------------------
// API helper
// ---------------------------------------------------------------------------
async function api(method, path, body, isForm) {
  const opts = { method, headers: {}, credentials: 'same-origin' };
  if (isForm) {
    opts.body = body;
  } else if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(`/api${path}`, opts);
  let data = null;
  try { data = await res.json(); } catch (e) { /* no body */ }

  if (res.status === 403 && data && data.error === 'banned') {
    showBanScreen(data);
    throw new Error('banned');
  }
  if (!res.ok) {
    const err = new Error((data && (data.error || data.message)) || `Request failed (${res.status})`);
    err.fields = data && data.fields;
    err.status = res.status;
    err.raw = data;
    throw err;
  }
  return data;
}

// ---------------------------------------------------------------------------
// View switching
// ---------------------------------------------------------------------------
function showOnly(id) {
  ['app-loading', 'view-login', 'view-register', 'view-banned', 'view-app'].forEach((v) => {
    document.getElementById(v).classList.toggle('hidden', v !== id);
  });
}

function showBanScreen(banData) {
  document.getElementById('ban-reason').textContent = banData.reason || 'No reason provided.';
  document.getElementById('ban-duration').textContent = banData.permanent
    ? 'Permanent'
    : banData.expiresAt
    ? `Until ${new Date(banData.expiresAt).toLocaleString()}`
    : 'Indefinite';
  showOnly('view-banned');
  closeSettings();
  closeAdmin();
}

// ---------------------------------------------------------------------------
// Toasts
// ---------------------------------------------------------------------------
function toast(message, type = 'default') {
  const stack = document.getElementById('toast-stack');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    el.style.transition = 'opacity 0.2s ease';
    setTimeout(() => el.remove(), 220);
  }, 3200);
}

// ---------------------------------------------------------------------------
// Field error helpers
// ---------------------------------------------------------------------------
function clearFieldErrors(formEl) {
  formEl.querySelectorAll('.field').forEach((f) => {
    f.classList.remove('has-error');
    const et = f.querySelector('.error-text');
    if (et && et.dataset.default === undefined) { /* keep static hints */ }
  });
}
function setFieldError(fieldId, message) {
  const field = document.getElementById(fieldId);
  if (!field) return;
  field.classList.add('has-error');
  const et = field.querySelector('.error-text');
  if (et && message) et.textContent = message;
}
function setBanner(bannerId, message, type) {
  const el = document.getElementById(bannerId);
  el.textContent = message;
  el.className = `form-banner show ${type}`;
}
function hideBanner(bannerId) {
  document.getElementById(bannerId).className = 'form-banner';
}

function initials(name) {
  if (!name) return '?';
  return name.trim().slice(0, 2).toUpperCase();
}

function avatarHtml(user, size) {
  if (user.avatarUrl) {
    return `<img src="${user.avatarUrl}" alt="${escapeHtml(user.displayName || user.username)}" />`;
  }
  return escapeHtml(initials(user.displayName || user.username));
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

// ---------------------------------------------------------------------------
// Auth: login / register
// ---------------------------------------------------------------------------
document.getElementById('go-register').addEventListener('click', () => showOnly('view-register'));
document.getElementById('go-login').addEventListener('click', () => showOnly('view-login'));

document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  hideBanner('login-banner');
  clearFieldErrors(e.target);
  document.getElementById('login-username-field').classList.remove('has-error');
  document.getElementById('login-password-field').classList.remove('has-error');

  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;
  const btn = document.getElementById('login-submit');
  btn.disabled = true;

  try {
    const data = await api('POST', '/auth/login', { username, password });
    state.user = data.user;
    toast(`Welcome back, ${data.user.displayName}.`, 'success');
    await bootApp();
  } catch (err) {
    if (err.message === 'banned') return;
    setBanner('login-banner', err.message, 'error');
  } finally {
    btn.disabled = false;
  }
});

document.getElementById('register-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  hideBanner('register-banner');
  ['reg-displayName-field', 'reg-username-field', 'reg-email-field', 'reg-password-field'].forEach((id) => {
    document.getElementById(id).classList.remove('has-error');
  });

  const displayName = document.getElementById('reg-displayName').value.trim();
  const username = document.getElementById('reg-username').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value;
  const btn = document.getElementById('register-submit');
  btn.disabled = true;

  try {
    const data = await api('POST', '/auth/register', { displayName, username, email, password });
    state.user = data.user;
    toast(`Welcome to Cove, ${data.user.displayName}.`, 'success');
    await bootApp();
  } catch (err) {
    if (err.message === 'banned') return;
    if (err.fields) {
      const map = { displayName: 'reg-displayName-field', username: 'reg-username-field', email: 'reg-email-field', password: 'reg-password-field' };
      Object.entries(err.fields).forEach(([key, msg]) => {
        const fieldId = map[key];
        if (fieldId) {
          const field = document.getElementById(fieldId);
          field.classList.add('has-error');
          field.querySelector('.error-text').textContent = msg;
        }
      });
      setBanner('register-banner', 'Please fix the highlighted fields.', 'error');
    } else {
      setBanner('register-banner', err.message, 'error');
    }
  } finally {
    btn.disabled = false;
  }
});

document.getElementById('ban-logout-btn').addEventListener('click', async () => {
  await api('POST', '/auth/logout').catch(() => {});
  location.reload();
});

// ---------------------------------------------------------------------------
// Boot sequence
// ---------------------------------------------------------------------------
async function bootApp() {
  try {
    if (!state.user) {
      const data = await api('GET', '/auth/me');
      state.user = data.user;
    }
  } catch (err) {
    showOnly('view-login');
    return;
  }

  renderUserTray();
  document.getElementById('open-admin-btn').classList.toggle('hidden', state.user.role !== 'admin');

  connectSocket();
  await loadCoves();
  showOnly('view-app');
}

async function init() {
  try {
    const data = await api('GET', '/auth/me');
    state.user = data.user;
    await bootApp();
  } catch (err) {
    if (err.message === 'banned') return;
    showOnly('view-login');
  }
}

// ---------------------------------------------------------------------------
// Socket.IO
// ---------------------------------------------------------------------------
function connectSocket() {
  if (state.socket) state.socket.disconnect();
  state.socket = io({ withCredentials: true });

  state.socket.on('message:new', (msg) => {
    if (msg.channelId === state.activeChannelId) {
      appendMessage(msg);
      scrollMessagesToBottom();
    }
  });
  state.socket.on('message:edit', (msg) => {
    if (msg.channelId === state.activeChannelId) updateMessageInDom(msg);
  });
  state.socket.on('message:delete', ({ channelId, messageId }) => {
    if (channelId === state.activeChannelId) {
      const el = document.querySelector(`[data-message-id="${messageId}"]`);
      if (el) el.remove();
    }
  });
  state.socket.on('typing', ({ channelId, user }) => {
    if (channelId !== state.activeChannelId || user.id === state.user.id) return;
    state.typingUsers.set(user.id, { name: user.displayName, at: Date.now() });
    renderTyping();
  });
  state.socket.on('connect_error', () => { /* silent; REST still works */ });
}

function renderTyping() {
  const now = Date.now();
  for (const [id, v] of state.typingUsers) {
    if (now - v.at > 4000) state.typingUsers.delete(id);
  }
  const names = [...state.typingUsers.values()].map((v) => v.name);
  const el = document.getElementById('typing-indicator');
  if (names.length === 0) { el.textContent = ''; return; }
  if (names.length === 1) el.textContent = `${names[0]} is typing…`;
  else el.textContent = `${names.join(', ')} are typing…`;
}
setInterval(renderTyping, 1500);

// ---------------------------------------------------------------------------
// User tray
// ---------------------------------------------------------------------------
function renderUserTray() {
  document.getElementById('tray-avatar').innerHTML = avatarHtml(state.user);
  document.getElementById('tray-name').textContent = state.user.displayName;
  document.getElementById('tray-username').textContent = `@${state.user.username}`;
  const dot = document.getElementById('tray-status-dot');
  dot.className = `status-dot ${state.user.status}`;
}

// ---------------------------------------------------------------------------
// Coves + channels
// ---------------------------------------------------------------------------
async function loadCoves() {
  const data = await api('GET', '/coves');
  state.coves = data.coves;
  renderCoveRail();
  if (state.coves.length > 0) {
    const firstCove = state.coves[0];
    await selectCove(firstCove.id);
  }
}

function renderCoveRail() {
  const rail = document.getElementById('cove-rail');
  rail.querySelectorAll('.cove-icon:not(.add)').forEach((el) => el.remove());
  const addBtn = document.getElementById('create-cove-btn');
  state.coves.forEach((cove) => {
    const el = document.createElement('div');
    el.className = 'cove-icon' + (cove.id === state.activeCoveId ? ' active' : '');
    el.textContent = cove.iconText;
    el.title = cove.name;
    el.addEventListener('click', () => selectCove(cove.id));
    rail.insertBefore(el, addBtn);
  });
}

async function selectCove(coveId) {
  state.activeCoveId = coveId;
  const cove = state.coves.find((c) => c.id === coveId);
  if (!cove) return;
  document.getElementById('active-cove-name').textContent = cove.name;
  renderCoveRail();
  renderChannelList(cove);

  const membersData = await api('GET', `/coves/${coveId}/members`);
  state.members = membersData.members;
  renderMemberList();

  if (cove.channels.length > 0) {
    await selectChannel(cove.channels[0].id);
  } else {
    document.getElementById('message-scroll').innerHTML = '<div class="empty-channel">No channels yet.</div>';
  }
}

function renderChannelList(cove) {
  const list = document.getElementById('channel-list');
  list.innerHTML = '';
  cove.channels.forEach((ch) => {
    const el = document.createElement('div');
    el.className = 'channel-item' + (ch.id === state.activeChannelId ? ' active' : '');
    el.innerHTML = `<span class="hash">#</span><span>${escapeHtml(ch.name)}</span>`;
    el.addEventListener('click', () => selectChannel(ch.id));
    list.appendChild(el);
  });
}

async function selectChannel(channelId) {
  if (state.activeChannelId && state.socket) {
    state.socket.emit('leave-channel', state.activeChannelId);
  }
  state.activeChannelId = channelId;
  state.typingUsers.clear();
  renderTyping();

  const cove = state.coves.find((c) => c.id === state.activeCoveId);
  const channel = cove.channels.find((c) => c.id === channelId);
  document.getElementById('active-channel-name').textContent = channel.name;
  document.getElementById('active-channel-topic').textContent = channel.topic || '';
  document.getElementById('composer-input').placeholder = `Message #${channel.name}`;
  renderChannelList(cove);

  if (state.socket) state.socket.emit('join-channel', channelId);

  const scroll = document.getElementById('message-scroll');
  scroll.innerHTML = '<div class="empty-channel">Loading messages…</div>';
  const data = await api('GET', `/messages/channel/${channelId}`);
  scroll.innerHTML = '';
  if (data.messages.length === 0) {
    scroll.innerHTML = '<div class="empty-channel"><div class="hash-big">#</div><div>No messages yet — say hello.</div></div>';
  } else {
    data.messages.forEach((m) => appendMessage(m));
    scrollMessagesToBottom();
  }
}

document.getElementById('create-cove-btn').addEventListener('click', async () => {
  const name = prompt('Name your new cove:');
  if (!name || !name.trim()) return;
  try {
    const data = await api('POST', '/coves', { name: name.trim() });
    state.coves.push(data.cove);
    toast(`"${data.cove.name}" created.`, 'success');
    await selectCove(data.cove.id);
  } catch (err) {
    toast(err.message, 'error');
  }
});

// ---------------------------------------------------------------------------
// Messages
// ---------------------------------------------------------------------------
function formatTime(iso) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

function appendMessage(msg) {
  const scroll = document.getElementById('message-scroll');
  const emptyState = scroll.querySelector('.empty-channel');
  if (emptyState) emptyState.remove();

  const row = document.createElement('div');
  row.className = 'message-row';
  row.dataset.messageId = msg.id;

  const isOwn = msg.author.id === state.user.id;
  const canModerate = isOwn || state.user.role === 'admin';

  row.innerHTML = `
    <div class="avatar" data-user-id="${msg.author.id}">${avatarHtml(msg.author)}</div>
    <div class="message-body">
      <div class="message-head">
        <span class="author" data-user-id="${msg.author.id}">${escapeHtml(msg.author.displayName)}</span>
        <span class="time">${formatTime(msg.createdAt)}</span>
      </div>
      <div class="message-content">${escapeHtml(msg.content)}${msg.editedAt ? '<span class="edited-tag">(edited)</span>' : ''}</div>
    </div>
    ${canModerate ? `<div class="msg-actions">
      ${isOwn ? '<button class="edit-btn">Edit</button>' : ''}
      <button class="delete-btn">Delete</button>
    </div>` : ''}
  `;

  row.querySelectorAll('[data-user-id]').forEach((el) => {
    el.addEventListener('click', () => openProfile(el.dataset.userId));
  });
  const editBtn = row.querySelector('.edit-btn');
  if (editBtn) editBtn.addEventListener('click', () => startEditMessage(msg.id));
  const deleteBtn = row.querySelector('.delete-btn');
  if (deleteBtn) deleteBtn.addEventListener('click', () => deleteMessage(msg.id));

  scroll.appendChild(row);
}

function updateMessageInDom(msg) {
  const row = document.querySelector(`[data-message-id="${msg.id}"]`);
  if (!row) return;
  const contentEl = row.querySelector('.message-content');
  contentEl.innerHTML = `${escapeHtml(msg.content)}<span class="edited-tag">(edited)</span>`;
}

function startEditMessage(messageId) {
  const row = document.querySelector(`[data-message-id="${messageId}"]`);
  const contentEl = row.querySelector('.message-content');
  const original = contentEl.textContent.replace(/\(edited\)\s*$/, '').trim();

  const input = document.createElement('textarea');
  input.value = original;
  input.rows = 1;
  input.style.cssText = 'width:100%;background:var(--bg-panel);border:1px solid var(--teal-dim);border-radius:6px;color:var(--text-primary);padding:8px;font-family:inherit;font-size:14.5px;';
  contentEl.replaceWith(input);
  input.focus();
  input.setSelectionRange(input.value.length, input.value.length);

  async function commit() {
    const newContent = input.value.trim();
    if (!newContent) { toast('Message cannot be empty.', 'error'); return; }
    try {
      await api('PATCH', `/messages/${messageId}`, { content: newContent });
    } catch (err) {
      toast(err.message, 'error');
    }
  }
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); commit(); }
    if (e.key === 'Escape') { updateMessageInDom({ id: messageId, content: original, editedAt: null }); }
  });
  input.addEventListener('blur', commit);
}

async function deleteMessage(messageId) {
  if (!confirm('Delete this message? This cannot be undone.')) return;
  try {
    await api('DELETE', `/messages/${messageId}`);
  } catch (err) {
    toast(err.message, 'error');
  }
}

function scrollMessagesToBottom() {
  const scroll = document.getElementById('message-scroll');
  scroll.scrollTop = scroll.scrollHeight;
}

async function sendCurrentMessage() {
  const input = document.getElementById('composer-input');
  const content = input.value.trim();
  if (!content || !state.activeChannelId) return;
  input.value = '';
  autoGrow(input);
  try {
    await api('POST', `/messages/channel/${state.activeChannelId}`, { content });
  } catch (err) {
    toast(err.message, 'error');
  }
}

const composerInput = document.getElementById('composer-input');
composerInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendCurrentMessage();
  }
});
let lastTypingEmit = 0;
composerInput.addEventListener('input', () => {
  autoGrow(composerInput);
  const now = Date.now();
  if (state.socket && state.activeChannelId && now - lastTypingEmit > 1500) {
    state.socket.emit('typing', state.activeChannelId);
    lastTypingEmit = now;
  }
});
function autoGrow(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 160) + 'px';
}
document.getElementById('send-btn').addEventListener('click', sendCurrentMessage);

// ---------------------------------------------------------------------------
// Members list
// ---------------------------------------------------------------------------
function renderMemberList() {
  const list = document.getElementById('member-list');
  list.innerHTML = '';
  state.members.forEach((m) => {
    const el = document.createElement('div');
    el.className = 'member-item' + (m.role === 'admin' ? ' is-admin' : '');
    el.innerHTML = `
      <div class="avatar-wrap">
        <div class="avatar">${avatarHtml(m)}</div>
        <span class="status-dot ${m.status}"></span>
      </div>
      <span class="name">${escapeHtml(m.displayName)}</span>
    `;
    el.addEventListener('click', () => openProfile(m.id));
    list.appendChild(el);
  });
}

// ---------------------------------------------------------------------------
// Profile popover
// ---------------------------------------------------------------------------
async function openProfile(userId) {
  try {
    const data = await api('GET', `/users/${userId}`);
    const u = data.user;
    document.getElementById('profile-banner').style.background = u.bannerUrl
      ? `url(${u.bannerUrl}) center/cover`
      : `linear-gradient(135deg, var(--teal-dim), ${u.bannerColor || 'var(--sand)'})`;
    document.getElementById('profile-avatar-lg').innerHTML = avatarHtml(u);
    document.getElementById('profile-display-name').textContent = u.displayName;
    document.getElementById('profile-username').textContent = `@${u.username}`;
    document.getElementById('profile-badges').innerHTML = u.role === 'admin' ? '<span class="badge admin">Administrator</span>' : '';
    document.getElementById('profile-about').textContent = u.aboutMe || 'This user hasn\u2019t written an about-me yet.';
    document.getElementById('profile-meta').textContent = `Member since ${new Date(u.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })} · ID ${u.id.slice(0, 8)}`;
    document.getElementById('profile-popover').classList.remove('hidden');
  } catch (err) {
    toast(err.message, 'error');
  }
}
document.getElementById('profile-close-btn').addEventListener('click', () => {
  document.getElementById('profile-popover').classList.add('hidden');
});
document.getElementById('profile-popover').addEventListener('click', (e) => {
  if (e.target.id === 'profile-popover') document.getElementById('profile-popover').classList.add('hidden');
});

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
function openSettings() {
  document.getElementById('settings-displayName').value = state.user.displayName;
  document.getElementById('settings-username-readonly').textContent = state.user.username;
  document.getElementById('settings-aboutMe').value = state.user.aboutMe || '';
  document.getElementById('settings-created').textContent = new Date(state.user.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
  document.getElementById('settings-avatar').innerHTML = avatarHtml(state.user);
  document.getElementById('settings-banner').style.background = state.user.bannerUrl
    ? `url(${state.user.bannerUrl}) center/cover`
    : `linear-gradient(135deg, var(--teal-dim), ${state.user.bannerColor || 'var(--sand)'})`;

  document.querySelectorAll('.status-option').forEach((el) => {
    el.classList.toggle('selected', el.dataset.status === state.user.status);
  });

  document.getElementById('view-settings').classList.remove('hidden');
}
function closeSettings() {
  document.getElementById('view-settings').classList.add('hidden');
}
document.getElementById('open-settings-btn').addEventListener('click', openSettings);
document.getElementById('settings-close-btn').addEventListener('click', closeSettings);
document.getElementById('settings-logout').addEventListener('click', async () => {
  await api('POST', '/auth/logout').catch(() => {});
  location.reload();
});

document.querySelectorAll('.settings-nav-item[data-panel]').forEach((navItem) => {
  navItem.addEventListener('click', () => {
    document.querySelectorAll('.settings-nav-item[data-panel]').forEach((n) => n.classList.remove('active'));
    navItem.classList.add('active');
    document.querySelectorAll('.settings-panel').forEach((p) => p.classList.add('hidden'));
    document.getElementById(`panel-${navItem.dataset.panel}`).classList.remove('hidden');
  });
});

document.querySelectorAll('.status-option').forEach((el) => {
  el.addEventListener('click', async () => {
    document.querySelectorAll('.status-option').forEach((o) => o.classList.remove('selected'));
    el.classList.add('selected');
    try {
      const data = await api('PATCH', '/users/me/profile', { status: el.dataset.status });
      state.user = data.user;
      renderUserTray();
      toast('Status updated.', 'success');
    } catch (err) {
      toast(err.message, 'error');
    }
  });
});

document.getElementById('save-profile-btn').addEventListener('click', async () => {
  document.getElementById('settings-displayName-field').classList.remove('has-error');
  const displayName = document.getElementById('settings-displayName').value.trim();
  const aboutMe = document.getElementById('settings-aboutMe').value.trim();
  try {
    const data = await api('PATCH', '/users/me/profile', { displayName, aboutMe });
    state.user = data.user;
    renderUserTray();
    toast('Profile saved.', 'success');
  } catch (err) {
    if (err.fields && err.fields.displayName) {
      const field = document.getElementById('settings-displayName-field');
      field.classList.add('has-error');
      field.querySelector('.error-text').textContent = err.fields.displayName;
    } else {
      toast(err.message, 'error');
    }
  }
});

document.getElementById('avatar-file-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const form = new FormData();
  form.append('avatar', file);
  try {
    const data = await api('POST', '/users/me/avatar', form, true);
    state.user.avatarUrl = data.avatarUrl;
    document.getElementById('settings-avatar').innerHTML = avatarHtml(state.user);
    renderUserTray();
    toast('Avatar updated.', 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
  e.target.value = '';
});

document.getElementById('banner-file-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const form = new FormData();
  form.append('banner', file);
  try {
    const data = await api('POST', '/users/me/banner', form, true);
    state.user.bannerUrl = data.bannerUrl;
    document.getElementById('settings-banner').style.background = `url(${data.bannerUrl}) center/cover`;
    toast('Banner updated.', 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
  e.target.value = '';
});

document.getElementById('change-password-btn').addEventListener('click', async () => {
  hideBanner('password-banner');
  document.getElementById('current-password-field').classList.remove('has-error');
  document.getElementById('new-password-field').classList.remove('has-error');
  const currentPassword = document.getElementById('current-password').value;
  const newPassword = document.getElementById('new-password').value;
  try {
    await api('POST', '/users/me/password', { currentPassword, newPassword });
    document.getElementById('current-password').value = '';
    document.getElementById('new-password').value = '';
    setBanner('password-banner', 'Password updated successfully.', 'success');
    toast('Password changed.', 'success');
  } catch (err) {
    if (err.fields) {
      Object.entries(err.fields).forEach(([key, msg]) => {
        const fieldId = key === 'currentPassword' ? 'current-password-field' : 'new-password-field';
        const field = document.getElementById(fieldId);
        field.classList.add('has-error');
        field.querySelector('.error-text').textContent = msg;
      });
    }
    setBanner('password-banner', err.message, 'error');
  }
});

// ---------------------------------------------------------------------------
// Admin panel
// ---------------------------------------------------------------------------
function openAdmin() {
  document.getElementById('view-admin').classList.remove('hidden');
  loadAdminUsers('');
}
function closeAdmin() {
  document.getElementById('view-admin').classList.add('hidden');
}
document.getElementById('open-admin-btn').addEventListener('click', openAdmin);
document.getElementById('admin-close-btn').addEventListener('click', closeAdmin);

let adminSearchDebounce = null;
document.getElementById('admin-search').addEventListener('input', (e) => {
  clearTimeout(adminSearchDebounce);
  adminSearchDebounce = setTimeout(() => loadAdminUsers(e.target.value.trim()), 250);
});

async function loadAdminUsers(query) {
  try {
    const data = await api('GET', `/admin/users${query ? `?q=${encodeURIComponent(query)}` : ''}`);
    renderAdminTable(data.users);
  } catch (err) {
    toast(err.message, 'error');
  }
}

function renderAdminTable(users) {
  const tbody = document.getElementById('admin-user-table');
  tbody.innerHTML = '';
  users.forEach((u) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>
        <div class="admin-user-cell">
          <div class="avatar" style="width:30px;height:30px;font-size:11px;">${avatarHtml(u)}</div>
          <div>
            <div style="font-weight:600;">${escapeHtml(u.displayName)}</div>
            <div style="color:var(--text-muted);font-size:12px;">@${escapeHtml(u.username)}</div>
          </div>
        </div>
      </td>
      <td>${new Date(u.createdAt).toLocaleDateString()}</td>
      <td>${u.role === 'admin' ? '<span class="pill admin">Admin</span>' : 'Member'}</td>
      <td>${u.banned ? '<span class="pill banned">Banned</span>' : '<span class="pill active">Active</span>'}</td>
      <td>
        <div class="admin-actions">
          <button class="btn btn-ghost btn-sm" data-action="view">View</button>
          <button class="btn btn-ghost btn-sm" data-action="rename">Rename</button>
          ${u.banned
            ? '<button class="btn btn-ghost btn-sm" data-action="unban">Unban</button>'
            : (u.role === 'admin' ? '' : '<button class="btn btn-danger btn-sm" data-action="ban">Ban</button>')}
        </div>
      </td>
    `;
    tr.querySelector('[data-action="view"]').addEventListener('click', () => openProfile(u.id));
    tr.querySelector('[data-action="rename"]').addEventListener('click', () => openRenameModal(u));
    const banBtn = tr.querySelector('[data-action="ban"]');
    if (banBtn) banBtn.addEventListener('click', () => openBanModal(u));
    const unbanBtn = tr.querySelector('[data-action="unban"]');
    if (unbanBtn) unbanBtn.addEventListener('click', () => unbanUser(u));
    tbody.appendChild(tr);
  });
}

function openModal(html) {
  document.getElementById('modal-card').innerHTML = html;
  document.getElementById('modal-backdrop').classList.remove('hidden');
}
function closeModal() {
  document.getElementById('modal-backdrop').classList.add('hidden');
}
document.getElementById('modal-backdrop').addEventListener('click', (e) => {
  if (e.target.id === 'modal-backdrop') closeModal();
});

function openBanModal(user) {
  openModal(`
    <h3>Ban @${escapeHtml(user.username)}</h3>
    <div class="field" style="margin-top:0;">
      <label>Reason</label>
      <textarea id="ban-reason-input" rows="2" placeholder="Why is this user being banned?"></textarea>
    </div>
    <div class="radio-row"><input type="radio" name="ban-type" value="permanent" id="ban-type-permanent" checked><label for="ban-type-permanent">Permanent ban</label></div>
    <div class="radio-row"><input type="radio" name="ban-type" value="temp" id="ban-type-temp"><label for="ban-type-temp">Temporary ban, for</label>
      <input type="number" id="ban-duration-hours" min="1" value="24" style="width:70px;background:var(--bg-panel);border:1px solid var(--border-soft);border-radius:6px;color:var(--text-primary);padding:5px 8px;" disabled> hours
    </div>
    <div class="modal-actions">
      <button class="btn btn-ghost btn-sm" id="modal-cancel">Cancel</button>
      <button class="btn btn-danger btn-sm" id="modal-confirm-ban">Ban user</button>
    </div>
  `);
  document.getElementById('modal-cancel').addEventListener('click', closeModal);
  document.querySelectorAll('input[name="ban-type"]').forEach((r) => {
    r.addEventListener('change', () => {
      document.getElementById('ban-duration-hours').disabled = document.getElementById('ban-type-permanent').checked;
    });
  });
  document.getElementById('modal-confirm-ban').addEventListener('click', async () => {
    const reason = document.getElementById('ban-reason-input').value.trim();
    const permanent = document.getElementById('ban-type-permanent').checked;
    const durationHours = permanent ? undefined : Number(document.getElementById('ban-duration-hours').value);
    try {
      await api('POST', `/admin/users/${user.id}/ban`, { reason, permanent, durationHours });
      toast(`@${user.username} has been banned.`, 'success');
      closeModal();
      loadAdminUsers(document.getElementById('admin-search').value.trim());
    } catch (err) {
      toast(err.message, 'error');
    }
  });
}

async function unbanUser(user) {
  if (!confirm(`Unban @${user.username}?`)) return;
  try {
    await api('POST', `/admin/users/${user.id}/unban`);
    toast(`@${user.username} has been unbanned.`, 'success');
    loadAdminUsers(document.getElementById('admin-search').value.trim());
  } catch (err) {
    toast(err.message, 'error');
  }
}

function openRenameModal(user) {
  openModal(`
    <h3>Edit @${escapeHtml(user.username)}</h3>
    <div class="field" style="margin-top:0;">
      <label>Username</label>
      <input type="text" id="rename-username-input" value="${escapeHtml(user.username)}" />
    </div>
    <div class="field">
      <label>Display name</label>
      <input type="text" id="rename-displayname-input" value="${escapeHtml(user.displayName)}" />
    </div>
    <div class="modal-actions">
      <button class="btn btn-ghost btn-sm" id="modal-cancel">Cancel</button>
      <button class="btn btn-primary btn-sm" id="modal-confirm-rename">Save</button>
    </div>
  `);
  document.getElementById('modal-cancel').addEventListener('click', closeModal);
  document.getElementById('modal-confirm-rename').addEventListener('click', async () => {
    const username = document.getElementById('rename-username-input').value.trim();
    const displayName = document.getElementById('rename-displayname-input').value.trim();
    try {
      if (username !== user.username) {
        await api('PATCH', `/admin/users/${user.id}/username`, { username });
      }
      if (displayName !== user.displayName) {
        await api('PATCH', `/admin/users/${user.id}/display-name`, { displayName });
      }
      toast('User updated.', 'success');
      closeModal();
      loadAdminUsers(document.getElementById('admin-search').value.trim());
    } catch (err) {
      toast(err.message, 'error');
    }
  });
}

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------
init();
