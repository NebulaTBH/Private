const jwt = require('jsonwebtoken');
const { db } = require('../database/db');

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';

// Verifies the session cookie and attaches the current user (fresh from DB) to req.user.
// Rejects the request if the token is missing/invalid, the account no longer exists,
// or the account is currently banned. This runs on the server for every protected
// route, so a user can never bypass it by editing frontend JavaScript.
function requireAuth(req, res, next) {
  const token = req.cookies && req.cookies.cove_session;
  if (!token) {
    return res.status(401).json({ error: 'Not logged in.' });
  }

  let payload;
  try {
    payload = jwt.verify(token, JWT_SECRET);
  } catch (err) {
    res.clearCookie('cove_session');
    return res.status(401).json({ error: 'Your session has expired. Please log in again.' });
  }

  const user = db.prepare(
    'SELECT id, username, display_name, email, avatar_url, banner_url, banner_color, about_me, status, role, created_at FROM users WHERE id = ?'
  ).get(payload.userId);

  if (!user) {
    res.clearCookie('cove_session');
    return res.status(401).json({ error: 'Account no longer exists.' });
  }

  const activeBan = db.prepare(
    `SELECT * FROM bans WHERE user_id = ? AND active = 1
     AND (is_permanent = 1 OR expires_at IS NULL OR expires_at > ?)
     ORDER BY banned_at DESC LIMIT 1`
  ).get(user.id, new Date().toISOString());

  if (activeBan) {
    res.clearCookie('cove_session');
    return res.status(403).json({
      error: 'banned',
      message: 'This account has been banned.',
      reason: activeBan.reason,
      permanent: !!activeBan.is_permanent,
      expiresAt: activeBan.expires_at,
    });
  }

  req.user = user;
  next();
}

// Optional auth: attaches req.user if a valid session exists, but never blocks the request.
function optionalAuth(req, res, next) {
  const token = req.cookies && req.cookies.cove_session;
  if (!token) return next();
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.prepare(
      'SELECT id, username, display_name, email, avatar_url, banner_url, banner_color, about_me, status, role, created_at FROM users WHERE id = ?'
    ).get(payload.userId);
    if (user) req.user = user;
  } catch (err) {
    // ignore invalid token for optional auth
  }
  next();
}

module.exports = { requireAuth, optionalAuth, JWT_SECRET };
