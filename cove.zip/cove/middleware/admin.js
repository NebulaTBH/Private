// Must run AFTER requireAuth. Checks the role that was just loaded fresh from the
// database (not anything sent by the client), so a regular user calling an admin
// API endpoint directly is rejected no matter what their frontend shows.
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Administrator access required.' });
  }
  next();
}

module.exports = { requireAdmin };
