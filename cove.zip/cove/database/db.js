const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const { v4: uuid } = require('uuid');
const bcrypt = require('bcryptjs');

const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, 'cove.db');
const SCHEMA_PATH = path.join(__dirname, 'schema.sql');

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Apply schema (idempotent - uses CREATE TABLE IF NOT EXISTS)
const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
db.exec(schema);

// --- First-run seed: a default Cove with a couple of channels, so the app isn't empty ---
function seedDefaults() {
  const coveCount = db.prepare('SELECT COUNT(*) AS c FROM coves').get().c;
  if (coveCount > 0) return;

  const now = new Date().toISOString();

  // We need at least one user to "own" the default cove. If no users exist yet,
  // defer seeding until the first user registers (see routes/auth.js).
  const userCount = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (userCount === 0) return;

  const firstUser = db.prepare('SELECT id FROM users ORDER BY created_at ASC LIMIT 1').get();
  const coveId = uuid();
  db.prepare(
    'INSERT INTO coves (id, name, icon_text, owner_id, created_at) VALUES (?, ?, ?, ?, ?)'
  ).run(coveId, 'Welcome Cove', 'WC', firstUser.id, now);

  db.prepare(
    'INSERT INTO cove_members (cove_id, user_id, joined_at) VALUES (?, ?, ?)'
  ).run(coveId, firstUser.id, now);

  const generalId = uuid();
  const randomId = uuid();
  db.prepare(
    'INSERT INTO channels (id, cove_id, name, topic, position, created_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(generalId, coveId, 'general', 'Say hello 👋', 0, now);
  db.prepare(
    'INSERT INTO channels (id, cove_id, name, topic, position, created_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(randomId, coveId, 'random', 'Anything goes', 1, now);
}

module.exports = { db, seedDefaults, uuid };
