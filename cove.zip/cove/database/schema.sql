-- Cove database schema
-- SQLite file-based database so data persists across restarts.

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,         -- unique, immutable-by-user handle (lowercase, stored as typed for display of case? we store lowercase canonical + original)
  username_lower TEXT UNIQUE NOT NULL,   -- lowercase canonical form used for uniqueness checks
  display_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  email_lower TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  avatar_url TEXT,
  banner_url TEXT,
  banner_color TEXT DEFAULT '#4DD8C4',
  about_me TEXT DEFAULT '',
  status TEXT DEFAULT 'online',          -- online | idle | dnd | offline
  role TEXT NOT NULL DEFAULT 'member',   -- member | admin
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bans (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  is_permanent INTEGER NOT NULL DEFAULT 0,
  expires_at TEXT,                       -- null if permanent or no expiry chosen
  banned_by TEXT NOT NULL REFERENCES users(id),
  banned_at TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,     -- set to 0 when unbanned
  unbanned_by TEXT REFERENCES users(id),
  unbanned_at TEXT
);

CREATE TABLE IF NOT EXISTS coves (
  id TEXT PRIMARY KEY,                   -- "coves" = servers/communities
  name TEXT NOT NULL,
  icon_text TEXT NOT NULL,               -- short letters used as an icon (no image needed)
  owner_id TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS cove_members (
  cove_id TEXT NOT NULL REFERENCES coves(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  joined_at TEXT NOT NULL,
  PRIMARY KEY (cove_id, user_id)
);

CREATE TABLE IF NOT EXISTS channels (
  id TEXT PRIMARY KEY,
  cove_id TEXT NOT NULL REFERENCES coves(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  topic TEXT DEFAULT '',
  position INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  channel_id TEXT NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id),
  content TEXT NOT NULL,
  created_at TEXT NOT NULL,
  edited_at TEXT,
  deleted INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_messages_channel ON messages(channel_id, created_at);
CREATE INDEX IF NOT EXISTS idx_bans_user ON bans(user_id, active);
CREATE INDEX IF NOT EXISTS idx_channels_cove ON channels(cove_id, position);
