// Usage: node database/make-admin.js <username>
// Promotes an existing user account to the "admin" role.

require('dotenv').config();
const { db } = require('./db');

const username = process.argv[2];

if (!username) {
  console.error('Usage: node database/make-admin.js <username>');
  process.exit(1);
}

const usernameLower = username.trim().toLowerCase();
const user = db.prepare('SELECT id, username, role FROM users WHERE username_lower = ?').get(usernameLower);

if (!user) {
  console.error(`No user found with username "${username}". Register the account first, then run this command.`);
  process.exit(1);
}

if (user.role === 'admin') {
  console.log(`"${user.username}" is already an administrator.`);
  process.exit(0);
}

db.prepare('UPDATE users SET role = ?, updated_at = ? WHERE id = ?').run(
  'admin',
  new Date().toISOString(),
  user.id
);

console.log(`✅ "${user.username}" is now an administrator.`);
